// 场景状态
export type SceneStatus = 'pending' | 'generating' | 'generated' | 'confirmed' | 'audit_fail';

// 场景
export interface Scene {
  id: string;
  chapterId: string;
  name: string;
  status: SceneStatus;
  order: number;
}

// 章节
export interface Chapter {
  id: string;
  name: string;
  scenes: Scene[];
  expanded: boolean;
  order: number;
}

// 角色
export interface Character {
  id: string;
  name: string;
  avatar?: string;
  description: string;
  personality: string;
}

// 项目蓝图
export interface ProjectBlueprint {
  title: string;
  genre: string;
  tone: string;
  characters: Character[];
  chapters: {
    id: string;
    name: string;
    description: string;
    sceneCount: number;
  }[];
}

// 审计问题
export interface AuditIssue {
  id: string;
  type: 'blocking' | 'warning';
  message: string;
  sceneId?: string;
  lineNumber?: number;
}

// 审计报告
export interface AuditReport {
  chapterId: string;
  status: 'passed' | 'failed';
  issues: AuditIssue[];
  score: number;
}

// 消息类型
export type MessageType = 'text' | 'blueprint' | 'progress' | 'audit' | 'resource';

// 聊天消息
export interface ChatMessage {
  id: string;
  role: 'user' | 'assistant';
  type: MessageType;
  content: string;
  data?: any;
  timestamp: number;
}

// 生成进度
export interface GenerationProgress {
  chapterId: string;
  sceneId: string;
  sceneName: string;
  step: string;
  percent: number;
}

// 资源候选
export interface ResourceCandidate {
  id: string;
  type: 'background' | 'character' | 'audio';
  urls: string[];
  sceneId: string;
}

// 应用状态
export interface AppState {
  currentProject: string;
  selectedChapterId: string | null;
  selectedSceneId: string | null;
  activeTab: string;
  chapters: Chapter[];
  blueprint: ProjectBlueprint | null;
  auditReport: AuditReport | null;
  isGenerating: boolean;
  generationProgress: GenerationProgress | null;
}
