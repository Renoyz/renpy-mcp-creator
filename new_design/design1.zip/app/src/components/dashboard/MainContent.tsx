import { useAppStore } from '@/store/appStore';
import { BlueprintView } from './BlueprintView';
import { ScriptEditor } from './ScriptEditor';
import { AuditReportView } from './AuditReportView';
import { Tabs, TabsList, TabsTrigger } from '@/components/ui/tabs';
import { FileText, Map, ClipboardCheck, Code, Image, AlertCircle } from 'lucide-react';
import { cn } from '@/lib/utils';
import type { Chapter, Scene } from '@/types';

export function MainContent() {
  const { activeTab, setActiveTab, selectedSceneId } = useAppStore();

  // 根据是否选中场景决定显示哪些标签
  const isSceneSelected = !!selectedSceneId;

  return (
    <div className="h-full flex flex-col bg-white dark:bg-gray-950">
      {/* Tabs */}
      <div className="border-b border-gray-200 dark:border-gray-800">
        {isSceneSelected ? (
          // 场景级别标签
          <Tabs value={activeTab} onValueChange={setActiveTab}>
            <TabsList className="w-full justify-start rounded-none bg-transparent border-b-0 p-0 h-12">
              <TabsTrigger
                value="script"
                className={cn(
                  "rounded-none border-b-2 border-transparent data-[state=active]:border-blue-500 data-[state=active]:bg-transparent data-[state=active]:shadow-none px-4 gap-2"
                )}
              >
                <Code className="w-4 h-4" />
                脚本
              </TabsTrigger>
              <TabsTrigger
                value="resources"
                className={cn(
                  "rounded-none border-b-2 border-transparent data-[state=active]:border-blue-500 data-[state=active]:bg-transparent data-[state=active]:shadow-none px-4 gap-2"
                )}
              >
                <Image className="w-4 h-4" />
                资源
              </TabsTrigger>
              <TabsTrigger
                value="audit"
                className={cn(
                  "rounded-none border-b-2 border-transparent data-[state=active]:border-blue-500 data-[state=active]:bg-transparent data-[state=active]:shadow-none px-4 gap-2"
                )}
              >
                <AlertCircle className="w-4 h-4" />
                审计
              </TabsTrigger>
            </TabsList>
          </Tabs>
        ) : (
          // 项目/章节级别标签
          <Tabs value={activeTab} onValueChange={setActiveTab}>
            <TabsList className="w-full justify-start rounded-none bg-transparent border-b-0 p-0 h-12">
              <TabsTrigger
                value="blueprint"
                className={cn(
                  "rounded-none border-b-2 border-transparent data-[state=active]:border-blue-500 data-[state=active]:bg-transparent data-[state=active]:shadow-none px-4 gap-2"
                )}
              >
                <FileText className="w-4 h-4" />
                蓝图
              </TabsTrigger>
              <TabsTrigger
                value="storymap"
                className={cn(
                  "rounded-none border-b-2 border-transparent data-[state=active]:border-blue-500 data-[state=active]:bg-transparent data-[state=active]:shadow-none px-4 gap-2"
                )}
              >
                <Map className="w-4 h-4" />
                Story Map
              </TabsTrigger>
              <TabsTrigger
                value="audit"
                className={cn(
                  "rounded-none border-b-2 border-transparent data-[state=active]:border-blue-500 data-[state=active]:bg-transparent data-[state=active]:shadow-none px-4 gap-2"
                )}
              >
                <ClipboardCheck className="w-4 h-4" />
                审计报告
              </TabsTrigger>
            </TabsList>
          </Tabs>
        )}
      </div>

      {/* Content */}
      <div className="flex-1 overflow-hidden">
        {isSceneSelected ? (
          // 场景级别内容
          <>
            {activeTab === 'script' && <ScriptEditor />}
            {activeTab === 'resources' && <ResourcesView />}
            {activeTab === 'audit' && <AuditReportView />}
          </>
        ) : (
          // 项目/章节级别内容
          <>
            {activeTab === 'blueprint' && <BlueprintView />}
            {activeTab === 'storymap' && <StoryMapView />}
            {activeTab === 'audit' && <AuditReportView />}
          </>
        )}
      </div>
    </div>
  );
}

// 资源视图
function ResourcesView() {
  const { selectedSceneId, chapters } = useAppStore();
  
  let sceneName = '';
  for (const ch of chapters) {
    const scene = ch.scenes.find((s: Scene) => s.id === selectedSceneId);
    if (scene) {
      sceneName = scene.name;
      break;
    }
  }

  const resources = [
    { type: 'background', name: 'bg_library_morning.jpg', status: 'ready' },
    { type: 'character', name: 'sakura_neutral.png', status: 'ready' },
    { type: 'character', name: 'sakura_surprised.png', status: 'ready' },
    { type: 'character', name: 'sakura_shy.png', status: 'ready' },
    { type: 'audio', name: 'bgm_peaceful.mp3', status: 'ready' },
  ];

  return (
    <div className="h-full overflow-y-auto p-6">
      <h3 className="text-lg font-semibold text-gray-900 dark:text-white mb-4">
        {sceneName} 的资源
      </h3>
      
      <div className="grid grid-cols-3 gap-4">
        {resources.map((res, index) => (
          <div
            key={index}
            className="p-4 rounded-xl bg-gray-50 dark:bg-gray-900 border border-gray-200 dark:border-gray-800"
          >
            <div className="aspect-video rounded-lg bg-gray-200 dark:bg-gray-800 mb-3 flex items-center justify-center">
              {res.type === 'background' && <div className="text-4xl">🖼️</div>}
              {res.type === 'character' && <div className="text-4xl">👤</div>}
              {res.type === 'audio' && <div className="text-4xl">🎵</div>}
            </div>
            <p className="text-sm font-medium text-gray-900 dark:text-white truncate">
              {res.name}
            </p>
            <p className="text-xs text-gray-500 capitalize">{res.type}</p>
          </div>
        ))}
      </div>
    </div>
  );
}

// Story Map 视图
function StoryMapView() {
  const { chapters } = useAppStore();

  return (
    <div className="h-full overflow-y-auto p-6">
      <h3 className="text-lg font-semibold text-gray-900 dark:text-white mb-6">
        Story Map
      </h3>
      
      <div className="space-y-8">
        {chapters.map((chapter: Chapter, chIndex: number) => (
          <div key={chapter.id} className="relative">
            {/* Chapter Node */}
            <div className="flex items-center gap-4 mb-4">
              <div className="w-12 h-12 rounded-xl bg-gradient-to-br from-blue-500 to-purple-500 flex items-center justify-center text-white font-bold">
                {chIndex + 1}
              </div>
              <div>
                <h4 className="font-semibold text-gray-900 dark:text-white">
                  {chapter.name}
                </h4>
                <p className="text-sm text-gray-500">
                  {chapter.scenes.length} 个场景
                </p>
              </div>
            </div>
            
            {/* Scene Nodes */}
            <div className="ml-6 pl-10 border-l-2 border-gray-200 dark:border-gray-800 space-y-4">
              {chapter.scenes.map((scene: Scene, scIndex: number) => (
                <div
                  key={scene.id}
                  className="relative p-4 rounded-xl bg-white dark:bg-gray-800 border border-gray-200 dark:border-gray-700 shadow-sm"
                >
                  <div className="absolute -left-[45px] top-1/2 -translate-y-1/2 w-4 h-4 rounded-full bg-blue-500 border-4 border-white dark:border-gray-900" />
                  <div className="flex items-center justify-between">
                    <div>
                      <p className="font-medium text-gray-900 dark:text-white">
                        {scene.name}
                      </p>
                      <p className="text-sm text-gray-500">
                        Scene {chIndex + 1}.{scIndex + 1}
                      </p>
                    </div>
                    <span className={cn(
                      "px-2 py-1 rounded-full text-xs",
                      scene.status === 'confirmed' && "bg-green-100 text-green-700",
                      scene.status === 'generated' && "bg-blue-100 text-blue-700",
                      scene.status === 'audit_fail' && "bg-red-100 text-red-700",
                      scene.status === 'pending' && "bg-gray-100 text-gray-600",
                      scene.status === 'generating' && "bg-yellow-100 text-yellow-700",
                    )}>
                      {scene.status === 'confirmed' && '已确认'}
                      {scene.status === 'generated' && '已生成'}
                      {scene.status === 'audit_fail' && '审计失败'}
                      {scene.status === 'pending' && '待生成'}
                      {scene.status === 'generating' && '生成中'}
                    </span>
                  </div>
                </div>
              ))}
            </div>
          </div>
        ))}
      </div>
    </div>
  );
}
