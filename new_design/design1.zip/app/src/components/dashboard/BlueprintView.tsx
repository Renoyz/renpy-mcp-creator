import { useAppStore } from '@/store/appStore';
import { Users, BookOpen, Film, Sparkles, User, FileText } from 'lucide-react';

export function BlueprintView() {
  const { blueprint, selectedChapterId } = useAppStore();

  if (!blueprint) {
    return (
      <div className="flex items-center justify-center h-full text-gray-500">
        暂无蓝图数据
      </div>
    );
  }

  const filteredChapters = selectedChapterId
    ? blueprint.chapters.filter((ch: {id: string}) => ch.id === selectedChapterId)
    : blueprint.chapters;

  return (
    <div className="h-full overflow-y-auto p-6">
      {/* Header */}
      <div className="mb-8">
        <div className="flex items-center gap-3 mb-2">
          <div className="w-10 h-10 rounded-xl bg-gradient-to-br from-purple-500 to-pink-500 flex items-center justify-center">
            <Sparkles className="w-5 h-5 text-white" />
          </div>
          <div>
            <h2 className="text-xl font-bold text-gray-900 dark:text-white">
              {blueprint.title}
            </h2>
            <p className="text-sm text-gray-500">
              {blueprint.genre} · {blueprint.tone}
            </p>
          </div>
        </div>
      </div>

      {/* Characters Section */}
      <section className="mb-8">
        <div className="flex items-center gap-2 mb-4">
          <Users className="w-5 h-5 text-purple-500" />
          <h3 className="text-lg font-semibold text-gray-900 dark:text-white">
            角色表 (Cast)
          </h3>
        </div>
        
        <div className="grid grid-cols-2 gap-4">
          {blueprint.characters.map((char: {id: string; name: string; personality: string; description: string}) => (
            <div
              key={char.id}
              className="p-4 rounded-xl bg-white dark:bg-gray-800 border border-gray-200 dark:border-gray-700 shadow-sm hover:shadow-md transition-shadow"
            >
              <div className="flex items-center gap-3 mb-3">
                <div className="w-12 h-12 rounded-full bg-gradient-to-br from-blue-400 to-purple-400 flex items-center justify-center">
                  <User className="w-6 h-6 text-white" />
                </div>
                <div>
                  <h4 className="font-semibold text-gray-900 dark:text-white">
                    {char.name}
                  </h4>
                  <span className="text-xs px-2 py-0.5 rounded-full bg-purple-100 text-purple-700 dark:bg-purple-900/30 dark:text-purple-300">
                    {char.personality}
                  </span>
                </div>
              </div>
              <p className="text-sm text-gray-600 dark:text-gray-400">
                {char.description}
              </p>
            </div>
          ))}
        </div>
      </section>

      {/* Chapters Section */}
      <section className="mb-8">
        <div className="flex items-center gap-2 mb-4">
          <BookOpen className="w-5 h-5 text-blue-500" />
          <h3 className="text-lg font-semibold text-gray-900 dark:text-white">
            章节结构
          </h3>
        </div>
        
        <div className="space-y-3">
          {filteredChapters.map((chapter: {id: string; name: string; description: string; sceneCount: number}, index: number) => (
            <div
              key={chapter.id}
              className="p-4 rounded-xl bg-white dark:bg-gray-800 border border-gray-200 dark:border-gray-700 shadow-sm"
            >
              <div className="flex items-center gap-3">
                <div className="w-8 h-8 rounded-lg bg-gradient-to-br from-blue-500 to-cyan-500 flex items-center justify-center text-white text-sm font-bold">
                  {index + 1}
                </div>
                <div className="flex-1">
                  <h4 className="font-semibold text-gray-900 dark:text-white">
                    {chapter.name}
                  </h4>
                  <p className="text-sm text-gray-500">
                    {chapter.description}
                  </p>
                </div>
                <div className="flex items-center gap-1 text-sm text-gray-500">
                  <Film className="w-4 h-4" />
                  <span>{chapter.sceneCount} 场景</span>
                </div>
              </div>
            </div>
          ))}
        </div>
      </section>

      {/* Project Tone */}
      <section>
        <div className="flex items-center gap-2 mb-4">
          <FileText className="w-5 h-5 text-green-500" />
          <h3 className="text-lg font-semibold text-gray-900 dark:text-white">
            叙事基调
          </h3>
        </div>
        
        <div className="p-4 rounded-xl bg-gradient-to-r from-green-50 to-emerald-50 dark:from-green-900/20 dark:to-emerald-900/20 border border-green-200 dark:border-green-800">
          <p className="text-gray-700 dark:text-gray-300">
            整体风格为<span className="font-semibold text-green-700 dark:text-green-400">{blueprint.tone}</span>，
            注重细腻的情感描写和日常细节。对话自然流畅，避免过于戏剧化的冲突。
            背景设定在现代日本校园，季节为春季樱花盛开时。
          </p>
        </div>
      </section>
    </div>
  );
}
