import { ChapterTimeline } from './dashboard/ChapterTimeline';
import { MainContent } from './dashboard/MainContent';
import { QuickActions } from './dashboard/QuickActions';
import { useAppStore } from '@/store/appStore';
import { cn } from '@/lib/utils';

export function Dashboard() {
  const { selectedSceneId } = useAppStore();

  return (
    <div className="flex-1 flex overflow-hidden">
      {/* Left: Chapter Timeline */}
      <div className="w-56 flex-shrink-0">
        <ChapterTimeline />
      </div>

      {/* Center: Main Content */}
      <div className="flex-1 min-w-0">
        <MainContent />
      </div>

      {/* Right: Quick Actions */}
      <div className={cn(
        "w-44 flex-shrink-0 transition-all duration-300",
        selectedSceneId ? "opacity-100" : "opacity-70"
      )}>
        <QuickActions />
      </div>
    </div>
  );
}
