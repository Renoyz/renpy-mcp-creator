import { createContext, useContext, useState, useCallback, type ReactNode } from 'react';
import type { Chapter, Scene, SceneStatus, ProjectBlueprint, Character, GenerationProgress, AuditReport } from '@/types';

const mockCharacters: Character[] = [
  { id: 'c1', name: '樱', description: '女主角，图书馆管理员', personality: '温柔内向' },
  { id: 'c2', name: '小林', description: '男主角，转学生', personality: '开朗直率' },
];

const mockBlueprint: ProjectBlueprint = {
  title: 'campus_romance',
  genre: '校园恋爱',
  tone: '温馨治愈',
  characters: mockCharacters,
  chapters: [
    { id: 'ch1', name: '图书馆相遇', description: '转学生小林第一次遇见樱', sceneCount: 3 },
    { id: 'ch2', name: '社团活动', description: '两人加入同一个社团', sceneCount: 2 },
    { id: 'ch3', name: '告白', description: '小林鼓起勇气告白', sceneCount: 2 },
  ]
};

const mockChapters: Chapter[] = [
  {
    id: 'ch1',
    name: '图书馆相遇',
    expanded: true,
    order: 1,
    scenes: [
      { id: 's1-1', chapterId: 'ch1', name: '初见', status: 'confirmed', order: 1 },
      { id: 's1-2', chapterId: 'ch1', name: '借书', status: 'confirmed', order: 2 },
      { id: 's1-3', chapterId: 'ch1', name: '告别', status: 'audit_fail', order: 3 },
    ]
  },
  {
    id: 'ch2',
    name: '社团活动',
    expanded: false,
    order: 2,
    scenes: [
      { id: 's2-1', chapterId: 'ch2', name: '招募', status: 'generated', order: 1 },
      { id: 's2-2', chapterId: 'ch2', name: '合作', status: 'pending', order: 2 },
    ]
  },
  {
    id: 'ch3',
    name: '告白',
    expanded: false,
    order: 3,
    scenes: [
      { id: 's3-1', chapterId: 'ch3', name: '犹豫', status: 'pending', order: 1 },
      { id: 's3-2', chapterId: 'ch3', name: '决心', status: 'pending', order: 2 },
    ]
  },
];

const mockAuditReport: AuditReport = {
  chapterId: 'ch1',
  status: 'failed',
  score: 78,
  issues: [
    { id: 'i1', type: 'blocking', message: 'Scene 1.3 中角色"樱"的情绪与Blueprint设定不符', sceneId: 's1-3', lineNumber: 15 },
    { id: 'i2', type: 'warning', message: '背景图片"library_evening.jpg"分辨率过低', sceneId: 's1-2' },
  ]
};

interface AppState {
  currentProject: string;
  selectedChapterId: string | null;
  selectedSceneId: string | null;
  activeTab: string;
  chapters: Chapter[];
  blueprint: ProjectBlueprint | null;
  auditReport: AuditReport | null;
  isGenerating: boolean;
  generationProgress: GenerationProgress | null;
}

interface AppContextType extends AppState {
  setSelectedChapter: (chapterId: string | null) => void;
  setSelectedScene: (sceneId: string | null) => void;
  setActiveTab: (tab: string) => void;
  toggleChapter: (chapterId: string) => void;
  updateSceneStatus: (sceneId: string, status: SceneStatus) => void;
  confirmBlueprint: () => void;
  setAuditReport: (report: AuditReport | null) => void;
  fixIssue: (issueId: string) => void;
}

const AppContext = createContext<AppContextType | null>(null);

export function AppProvider({ children }: { children: ReactNode }) {
  const [state, setState] = useState<AppState>({
    currentProject: 'campus_romance',
    selectedChapterId: null,
    selectedSceneId: null,
    activeTab: 'blueprint',
    chapters: mockChapters,
    blueprint: mockBlueprint,
    auditReport: mockAuditReport,
    isGenerating: false,
    generationProgress: null,
  });

  const setSelectedChapter = useCallback((chapterId: string | null) => {
    setState(prev => ({
      ...prev,
      selectedChapterId: chapterId,
      selectedSceneId: null,
      activeTab: 'blueprint'
    }));
  }, []);

  const setSelectedScene = useCallback((sceneId: string | null) => {
    setState(prev => {
      let chapterId: string | null = null;
      for (const ch of prev.chapters) {
        const scene = ch.scenes.find((s: Scene) => s.id === sceneId);
        if (scene) {
          chapterId = ch.id;
          break;
        }
      }
      return {
        ...prev,
        selectedSceneId: sceneId,
        selectedChapterId: chapterId,
        activeTab: 'script'
      };
    });
  }, []);

  const setActiveTab = useCallback((tab: string) => {
    setState(prev => ({ ...prev, activeTab: tab }));
  }, []);

  const toggleChapter = useCallback((chapterId: string) => {
    setState(prev => ({
      ...prev,
      chapters: prev.chapters.map((ch: Chapter) => 
        ch.id === chapterId ? { ...ch, expanded: !ch.expanded } : ch
      )
    }));
  }, []);

  const updateSceneStatus = useCallback((sceneId: string, status: SceneStatus) => {
    setState(prev => ({
      ...prev,
      chapters: prev.chapters.map((ch: Chapter) => ({
        ...ch,
        scenes: ch.scenes.map((s: Scene) => 
          s.id === sceneId ? { ...s, status } : s
        )
      }))
    }));
  }, []);

  const confirmBlueprint = useCallback(() => {
    setState(prev => ({
      ...prev,
      isGenerating: true,
      generationProgress: {
        chapterId: 'ch1',
        sceneId: 's1-1',
        sceneName: '初见',
        step: '正在生成场景脚本...',
        percent: 0
      }
    }));
  }, []);

  const setAuditReport = useCallback((report: AuditReport | null) => {
    setState(prev => ({ ...prev, auditReport: report }));
  }, []);

  const fixIssue = useCallback((issueId: string) => {
    setState(prev => {
      if (!prev.auditReport) return prev;
      const updatedIssues = prev.auditReport.issues.filter(i => i.id !== issueId);
      return {
        ...prev,
        auditReport: {
          ...prev.auditReport,
          issues: updatedIssues,
          status: updatedIssues.length === 0 ? 'passed' : 'failed',
          score: updatedIssues.length === 0 ? 100 : prev.auditReport.score + 10
        }
      };
    });
  }, []);

  const value: AppContextType = {
    ...state,
    setSelectedChapter,
    setSelectedScene,
    setActiveTab,
    toggleChapter,
    updateSceneStatus,
    confirmBlueprint,
    setAuditReport,
    fixIssue,
  };

  return (
    <AppContext.Provider value={value}>
      {children}
    </AppContext.Provider>
  );
}

export function useAppStore() {
  const context = useContext(AppContext);
  if (!context) {
    throw new Error('useAppStore must be used within AppProvider');
  }
  return context;
}
