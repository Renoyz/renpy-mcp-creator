import { createContext, useContext, useState, useCallback, type ReactNode } from 'react';
import type { ChatMessage, MessageType } from '@/types';

const initialMessages: ChatMessage[] = [
  {
    id: '1',
    role: 'assistant',
    type: 'text',
    content: '欢迎来到 AI Galgame Creator！我已为你生成了项目蓝图，请查看左侧的 Blueprint 标签页确认细节。',
    timestamp: Date.now() - 60000
  },
  {
    id: '2',
    role: 'assistant',
    type: 'blueprint',
    content: '项目蓝图已生成',
    data: {
      title: 'campus_romance',
      genre: '校园恋爱',
      characters: [
        { name: '樱', role: '女主角' },
        { name: '小林', role: '男主角' }
      ],
      chapters: [
        { name: '图书馆相遇', scenes: 3 },
        { name: '社团活动', scenes: 2 },
        { name: '告白', scenes: 2 }
      ]
    },
    timestamp: Date.now() - 50000
  }
];

interface ChatStoreType {
  messages: ChatMessage[];
  inputValue: string;
  isTyping: boolean;
  setInputValue: (value: string) => void;
  sendMessage: (content: string, type?: MessageType, data?: unknown) => void;
  addAssistantMessage: (content: string, type?: MessageType, data?: unknown) => void;
  clearMessages: () => void;
  simulateGenerationProgress: () => void;
  simulateAuditReport: () => void;
}

const ChatContext = createContext<ChatStoreType | null>(null);

export function ChatProvider({ children }: { children: ReactNode }) {
  const [messages, setMessages] = useState<ChatMessage[]>(initialMessages);
  const [inputValue, setInputValueState] = useState('');
  const [isTyping, setIsTyping] = useState(false);

  const setInputValue = useCallback((value: string) => {
    setInputValueState(value);
  }, []);

  const addAssistantMessage = useCallback((content: string, type: MessageType = 'text', data: unknown = null) => {
    setIsTyping(true);
    
    setTimeout(() => {
      const newMessage: ChatMessage = {
        id: Date.now().toString(),
        role: 'assistant',
        type,
        content,
        data,
        timestamp: Date.now()
      };
      setMessages(prev => [...prev, newMessage]);
      setIsTyping(false);
    }, 600);
  }, []);

  const handleUserMessage = useCallback((content: string) => {
    const lowerContent = content.toLowerCase();
    
    if (lowerContent.includes('生成') || lowerContent.includes('开始')) {
      simulateGenerationProgress();
    } else if (lowerContent.includes('审计') || lowerContent.includes('检查')) {
      simulateAuditReport();
    } else if (lowerContent.includes('确认')) {
      addAssistantMessage('已确认 Blueprint，开始生成第一章...', 'progress', {
        chapterId: 'ch1',
        sceneId: 's1-1',
        sceneName: '初见',
        step: '准备生成...',
        percent: 10
      });
      setTimeout(() => simulateGenerationProgress(), 1000);
    } else {
      addAssistantMessage('收到！我会帮你处理这个请求。你可以尝试说"生成第一章"或"查看审计报告"。');
    }
  }, [addAssistantMessage]);

  const sendMessage = useCallback((content: string, type: MessageType = 'text', data: unknown = null) => {
    const newMessage: ChatMessage = {
      id: Date.now().toString(),
      role: 'user',
      type,
      content,
      data,
      timestamp: Date.now()
    };
    setMessages(prev => [...prev, newMessage]);
    setInputValueState('');

    setTimeout(() => {
      handleUserMessage(content);
    }, 500);
  }, [handleUserMessage]);

  const clearMessages = useCallback(() => {
    setMessages([]);
  }, []);

  const simulateGenerationProgress = useCallback(() => {
    const steps = [
      { step: '正在生成 Scene 1.1 - 初见...', percent: 25, sceneId: 's1-1', sceneName: '初见' },
      { step: '正在生成 Scene 1.2 - 借书...', percent: 50, sceneId: 's1-2', sceneName: '借书' },
      { step: '正在生成 Scene 1.3 - 告别...', percent: 75, sceneId: 's1-3', sceneName: '告别' },
      { step: '生成完成！正在审计...', percent: 100, sceneId: '', sceneName: '' },
    ];

    let currentStep = 0;
    
    const processStep = () => {
      if (currentStep < steps.length) {
        const step = steps[currentStep];
        addAssistantMessage(step.step, 'progress', { chapterId: 'ch1', ...step });
        currentStep++;
        setTimeout(processStep, 1500);
      } else {
        setTimeout(() => {
          addAssistantMessage(
            '第一章生成完成！发现 2 个问题需要修复。',
            'audit',
            {
              status: 'failed',
              score: 78,
              issues: [
                { id: 'i1', type: 'blocking', message: 'Scene 1.3 中角色"樱"的情绪与Blueprint设定不符' },
                { id: 'i2', type: 'warning', message: '背景图片分辨率过低' }
              ]
            }
          );
        }, 1000);
      }
    };

    processStep();
  }, [addAssistantMessage]);

  const simulateAuditReport = useCallback(() => {
    addAssistantMessage(
      '审计报告已生成',
      'audit',
      {
        status: 'failed',
        score: 78,
        issues: [
          { id: 'i1', type: 'blocking', message: 'Scene 1.3 中角色"樱"的情绪与Blueprint设定不符' },
          { id: 'i2', type: 'warning', message: '背景图片分辨率过低' }
        ]
      }
    );
  }, [addAssistantMessage]);

  const value: ChatStoreType = {
    messages,
    inputValue,
    isTyping,
    setInputValue,
    sendMessage,
    addAssistantMessage,
    clearMessages,
    simulateGenerationProgress,
    simulateAuditReport,
  };

  return (
    <ChatContext.Provider value={value}>
      {children}
    </ChatContext.Provider>
  );
}

export function useChatStore() {
  const context = useContext(ChatContext);
  if (!context) {
    throw new Error('useChatStore must be used within ChatProvider');
  }
  return context;
}
