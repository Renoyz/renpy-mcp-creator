import { TopBar } from '@/components/TopBar';
import { Dashboard } from '@/components/Dashboard';
import { ChatPanel } from '@/components/chat/ChatPanel';
import { StatusBar } from '@/components/StatusBar';

function App() {
  return (
    <div className="h-screen flex flex-col bg-white dark:bg-gray-950">
      {/* Top Bar */}
      <TopBar />

      {/* Main Content */}
      <div className="flex-1 flex overflow-hidden">
        {/* Left: Dashboard (65%) */}
        <div className="flex-1 flex flex-col min-w-0">
          <Dashboard />
        </div>

        {/* Right: Chat Panel (35%, fixed width) */}
        <div className="w-[400px] flex-shrink-0 border-l border-gray-200 dark:border-gray-800">
          <ChatPanel />
        </div>
      </div>

      {/* Status Bar */}
      <StatusBar />
    </div>
  );
}

export default App;
